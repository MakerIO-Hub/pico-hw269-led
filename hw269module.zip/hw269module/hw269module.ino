// Raspberry Pi Pico dimmable KS0010 / HW-269 3 W bedside light.
// GP15 PWM is raised from 3.3 V to safe 5 V logic by a 74AHCT125 before it
// reaches the module's S control input. The LED starts completely OFF.

const uint8_t ON_OFF_BUTTON_PIN = 14;     // GP14, physical pin 19
const uint8_t LED_MODULE_PIN = 15;        // GP15, physical pin 20 -> 74AHCT125 1A
const uint8_t BRIGHTNESS_UP_PIN = 4;      // GP4, physical pin 6
const uint8_t BRIGHTNESS_DOWN_PIN = 5;    // GP5, physical pin 7

const unsigned long BUTTON_DEBOUNCE_MS = 35;
const unsigned long BRIGHTNESS_REPEAT_DELAY_MS = 350; // Pause before hold-repeat starts.
const unsigned long BRIGHTNESS_REPEAT_MS = 100;       // Repeat rate while held.
const uint8_t BRIGHTNESS_STEP = 10;       // About 4% change per step.
const uint8_t INITIAL_BRIGHTNESS = 48;    // Gentle level saved after power-up.

struct DebouncedButton {
  uint8_t pin;
  bool lastRaw = HIGH;
  bool stable = HIGH;
  unsigned long lastChangeMs = 0;
};

bool ledIsOn = false;
uint8_t brightness = INITIAL_BRIGHTNESS;
DebouncedButton onOffButton{ON_OFF_BUTTON_PIN};
DebouncedButton brightnessUpButton{BRIGHTNESS_UP_PIN};
DebouncedButton brightnessDownButton{BRIGHTNESS_DOWN_PIN};
unsigned long brightnessUpNextRepeatMs = 0;
unsigned long brightnessDownNextRepeatMs = 0;

void applyLedOutput() {
  // A zero duty cycle makes the light fully off. Otherwise PWM on S controls
  // the module's average brightness without changing its 5 V power wiring.
  analogWrite(LED_MODULE_PIN, ledIsOn ? brightness : 0);
}

void printBrightness() {
  Serial.print("Brightness: ");
  Serial.print(brightness);
  Serial.print(" / 255");
  if (!ledIsOn) {
    Serial.print(" (saved; LED is off)");
  }
  Serial.println();
}

void setup() {
  // Configure PWM before enabling any light output. A zero duty cycle keeps
  // the LED off at startup and after reset.
  pinMode(LED_MODULE_PIN, OUTPUT);
  // The installed Raspberry Pi Pico Arduino core uses standard 8-bit
  // analogWrite: 0 is fully off and 255 is fully on.
  analogWrite(LED_MODULE_PIN, 0);

  // Every button connects its GPIO to GND when pressed. INPUT_PULLUP keeps
  // each input HIGH while its button is released, so no extra resistors are needed.
  pinMode(ON_OFF_BUTTON_PIN, INPUT_PULLUP);
  pinMode(BRIGHTNESS_UP_PIN, INPUT_PULLUP);
  pinMode(BRIGHTNESS_DOWN_PIN, INPUT_PULLUP);

  Serial.begin(115200);
  delay(300);
  Serial.println("Pico dimmable bedside light ready");
  Serial.println("GP14: on/off. GP4: brighter. GP5: dimmer.");
  printBrightness();
}

bool justPressed(DebouncedButton &button) {
  const bool raw = digitalRead(button.pin);
  const unsigned long now = millis();

  if (raw != button.lastRaw) {
    button.lastRaw = raw;
    button.lastChangeMs = now;
  }

  // A press is accepted only after 35 ms of steady contact. It returns true
  // once on the press edge; the brightness code separately uses the stable
  // held state to provide controlled automatic repeat.
  if ((now - button.lastChangeMs >= BUTTON_DEBOUNCE_MS) &&
      (raw != button.stable)) {
    button.stable = raw;
    return button.stable == LOW;
  }
  return false;
}

void changeBrightness(int change, const char *message) {
  const int newBrightness = constrain(static_cast<int>(brightness) + change, 0, 255);
  if (newBrightness != brightness) {
    brightness = static_cast<uint8_t>(newBrightness);
    applyLedOutput(); // Changes actual light output immediately when it is on.
    Serial.print(message);
    Serial.print(". ");
    printBrightness();
  }
}

void updateButtons() {
  const unsigned long now = millis();

  if (justPressed(onOffButton)) {
    ledIsOn = !ledIsOn;
    applyLedOutput();
    Serial.print("On/off press: LED is ");
    Serial.println(ledIsOn ? "ON" : "OFF");
    printBrightness();
  }

  // The first accepted press changes brightness immediately. If the button
  // stays down, repetition begins after a short pause and then occurs every
  // 100 ms. Releasing the button clears its stable LOW state immediately
  // after debounce, so no further brightness changes are made.
  if (justPressed(brightnessUpButton)) {
    changeBrightness(BRIGHTNESS_STEP, "Brighter");
    brightnessUpNextRepeatMs = now + BRIGHTNESS_REPEAT_DELAY_MS;
  } else if (brightnessUpButton.stable == LOW &&
             static_cast<long>(now - brightnessUpNextRepeatMs) >= 0) {
    changeBrightness(BRIGHTNESS_STEP, "Brighter");
    brightnessUpNextRepeatMs = now + BRIGHTNESS_REPEAT_MS;
  }

  if (justPressed(brightnessDownButton)) {
    changeBrightness(-BRIGHTNESS_STEP, "Dimmer");
    brightnessDownNextRepeatMs = now + BRIGHTNESS_REPEAT_DELAY_MS;
  } else if (brightnessDownButton.stable == LOW &&
             static_cast<long>(now - brightnessDownNextRepeatMs) >= 0) {
    changeBrightness(-BRIGHTNESS_STEP, "Dimmer");
    brightnessDownNextRepeatMs = now + BRIGHTNESS_REPEAT_MS;
  }
}

void loop() {
  updateButtons();
  delay(1); // Lets the RP2040 idle while still responding to button presses.
}
